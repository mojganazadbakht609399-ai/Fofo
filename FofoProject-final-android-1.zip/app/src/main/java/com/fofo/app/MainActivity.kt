package com.fofo.app

import android.app.*
import android.os.*
import android.content.*
import android.graphics.Color
import android.view.*
import android.view.animation.AlphaAnimation
import android.widget.*
import android.speech.RecognizerIntent
import android.speech.tts.TextToSpeech
import java.util.*

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var scene: TextView
    private lateinit var progress: TextView
    private lateinit var root: View
    private lateinit var tts: TextToSpeech
    private var step=0
    private val missions=listOf(
        listOf("🕵️ کارآگاه کوچولو","یک شیء گرد پیدا کن.","سه چیز هم‌رنگ آن پیدا کن.","پرونده حل شد! 🎉"),
        listOf("🌸 باغ جادویی","یک گل یا نقاشی گل پیدا کن.","برای گل یک اسم جادویی انتخاب کن.","جادو کامل شد! 🌈"),
        listOf("🚀 سفر فضایی","سه سیاره خیالی انتخاب کن.","صدای یک فضانورد را دربیاور!","سفینه آماده پرواز شد! 🚀"),
        listOf("🏰 قلعه اسباب‌بازی","سه اسباب‌بازی را نگهبان کن.","یک قانون بامزه برای قلعه بساز.","قلعه نجات پیدا کرد! 🏰")
    )
    private val mission by lazy { missions[Calendar.getInstance().get(Calendar.DAY_OF_YEAR)%missions.size] }

    override fun onCreate(b:Bundle?) {
        super.onCreate(b); setContentView(R.layout.activity_main)
        scene=findViewById(R.id.scene); progress=findViewById(R.id.progress); root=findViewById(R.id.root)
        tts=TextToSpeech(this,this)
        findViewById<Button>(R.id.challenge).setOnClickListener { step=1; showStep() }
        findViewById<Button>(R.id.talk).setOnClickListener { listen() }
        findViewById<Button>(R.id.magic).setOnClickListener { magic() }
        findViewById<Button>(R.id.parent).setOnClickListener { parentGate() }
    }
    private fun showStep(){
        if(step<mission.size){
            scene.text="🦊\n\n${mission[step]}"
            progress.text="★".repeat(step.coerceAtMost(3))+"☆".repeat((3-step).coerceAtLeast(0))
            speak(mission[step]); fade(scene)
        } else {
            scene.text="🦊🎉\n\n${mission[3]}"
            progress.text="★★★"; speak("آفرین! ماموریت امروز تمام شد!")
        }
    }
    private fun listen(){
        val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,"fa-IR")
        i.putExtra(RecognizerIntent.EXTRA_PROMPT,"جوابت رو به فوفو بگو")
        try { startActivityForResult(i,100) }
        catch(e:Exception){ Toast.makeText(this,"تشخیص صدا در این دستگاه در دسترس نیست.",Toast.LENGTH_SHORT).show() }
    }
    override fun onActivityResult(r:Int,c:Int,d:Intent?){
        super.onActivityResult(r,c,d)
        if(r==100 && c==RESULT_OK){
            val a=d?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()?:""
            scene.text="🦊\n\nشنیدم: «$a»\n\nآفرین! 🌟"
            speak("آفرین! خیلی خوب گفتی.")
            if(step in 1..2){ step++; showStep() }
        }
    }
    private fun magic(){
        scene.text="🦊✨\n\nجادوی فوفو فعال شد!\n\n${listOf("🌸","🦋","⭐","💎","🍄","🌈").random()}"
        fade(scene); root.setBackgroundColor(Color.rgb(242,232,255))
        root.postDelayed({root.setBackgroundColor(Color.rgb(255,248,255))},900)
        speak("جادوی فوفو فعال شد!")
    }
    private fun parentGate(){
        val input=EditText(this); input.hint="کد والدین"
        AlertDialog.Builder(this).setTitle("👨‍👩‍👧 بخش والدین").setMessage("کد نمونه: 1234").setView(input)
            .setNegativeButton("لغو",null).setPositiveButton("ورود"){_,_->
                if(input.text.toString()=="1234") settings()
                else Toast.makeText(this,"کد درست نیست.",Toast.LENGTH_SHORT).show()
            }.show()
    }
    private fun settings(){
        val box=LinearLayout(this); box.orientation=LinearLayout.VERTICAL; box.setPadding(30,10,30,10)
        val time=TimePicker(this); time.setIs24HourView(true)
        val label=TextView(this); label.text="مدت استفاده: 30 دقیقه"; label.textSize=17f
        val seek=SeekBar(this); seek.max=120; seek.progress=getPreferences(0).getInt("duration",30)
        seek.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener{
            override fun onProgressChanged(s:SeekBar?,p:Int,f:Boolean){label.text="مدت استفاده: ${p.coerceAtLeast(10)} دقیقه"}
            override fun onStartTrackingTouch(s:SeekBar?){}
            override fun onStopTrackingTouch(s:SeekBar?){}
        })
        box.addView(TextView(this).apply{text="⏰ ساعت سر زدن فوفو";textSize=17f})
        box.addView(time); box.addView(label); box.addView(seek)
        AlertDialog.Builder(this).setTitle("تنظیمات فوفو").setView(box).setNegativeButton("لغو",null)
            .setPositiveButton("ذخیره"){_,_->
                getPreferences(0).edit().putInt("duration",seek.progress.coerceAtLeast(10)).apply()
                schedule(time.hour,time.minute); Toast.makeText(this,"ذخیره شد.",Toast.LENGTH_SHORT).show()
            }.show()
    }
    private fun schedule(h:Int,m:Int){
        val am=getSystemService(ALARM_SERVICE) as AlarmManager
        val pi=PendingIntent.getBroadcast(this,77,Intent(this,ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val cal=Calendar.getInstance().apply{set(Calendar.HOUR_OF_DAY,h);set(Calendar.MINUTE,m);set(Calendar.SECOND,0)
            if(timeInMillis<=System.currentTimeMillis())add(Calendar.DAY_OF_YEAR,1)}
        am.set(AlarmManager.RTC_WAKEUP,cal.timeInMillis,pi)
    }
    private fun fade(v:View){val a=AlphaAnimation(0f,1f);a.duration=450;v.startAnimation(a)}
    private fun speak(s:String){if(::tts.isInitialized)tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"fofo")}
    override fun onInit(status:Int){if(status==TextToSpeech.SUCCESS)tts.language=Locale("fa","IR")}
    override fun onDestroy(){if(::tts.isInitialized){tts.stop();tts.shutdown()};super.onDestroy()}
}
class ReminderReceiver:BroadcastReceiver(){
    override fun onReceive(c:Context,i:Intent?){
        val nm=c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val ch="fofo"; if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(NotificationChannel(ch,"فوفو",NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(77,Notification.Builder(c,ch).setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("🦊 فوفو آماده‌ست!").setContentText("وقت یک ماجراجویی کوچولوست ✨").setAutoCancel(true).build())
    }
}