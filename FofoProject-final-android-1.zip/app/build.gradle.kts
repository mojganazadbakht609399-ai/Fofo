plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.fofo.app"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.fofo.app"
        minSdk = 24
        targetSdk = 35
        versionCode = 10
        versionName = "1.0"
    }
}
